/*
 * pwmled.h
 *
 *  Created on: 2021��6��27��
 *      Author: 13173
 */

#ifndef PWMLED_H_
#define PWMLED_H_

void PWM_Init();



#endif /* PWMLED_H_ */
