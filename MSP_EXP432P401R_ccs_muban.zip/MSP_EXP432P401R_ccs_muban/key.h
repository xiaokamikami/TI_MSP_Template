/*
 * key.h
 *
 *  Created on: 2021��6��28��
 *      Author: 13173
 */

#ifndef KEY_H_
#define KEY_H_

void Key_Init();


#endif /* KEY_H_ */
